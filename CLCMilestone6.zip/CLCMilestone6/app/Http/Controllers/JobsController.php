<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 21th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

// IMPORTANT

namespace App\Http\Controllers;

use App\Job;
use App\User;
use App\Http\Requests\Users\UpdateProfileRequest;
use App\Http\Requests\Jobs\UpdateJobRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;


    
class JobsController extends Controller
{

    
    // This method DISPLAYS a page with all the users for the admin
    public function index()
    {
        return view('users.index')->with('users', User::all());       
    }
    
    // To DISPLAY all job posting for and Admin
    public function jobs()
    {
        return view('jobs.index')->with('jobs', Job::all());
    }
    // To DISPLAY all jobs for anyone to see
    public function list()
    {
        return view('jobs.list')->with('jobs', Job::all());
    }
    
    public function show(Job $id)
    {
        return view('jobs.index', ['job'=>id]);
    }
    public function create()
    {
        return view('jobs.create');
    }
    public function store()
    {
        $job = new Job;
        
        $job->jobTitle = request('jobTitle');
        $job->companyName = request('companyName');
        $job->jobDescription = request('jobDescription');
        $job->jobLocation = request('jobLocation');
        $job->employmentType = request('employmentType');
        $job->applicants = request('applicants');
        $job->save();
    }
    
    public function edit($id)
    {
        // get the job
        $job = job::find($id);
        
        // show the eidt form and pass the job
        return view('jobs.edit')->with('job', $job);
    }
    
    public function update($id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'jobTitle'       => 'required',
            'companyName'      => 'required|companyName',
            'jobDescription'      => 'required|jobDescription',
            'jobLocation' => 'required|jobLocation',
            'employmentType' => 'required|employmentType'
        );
       /* $validator = Validator::make(Input::all(), $rules);
        
        // process the login
        if ($validator->fails()) {
            return Redirect::to('sharks/' . $id . '/edit')
            ->withErrors($validator)
            ->withInput(Input::except('password'));
        } else {*/
            // store
            $job = job::find($id);
            $job->jobTitle       = Input::get('jobTitle');
            $job->companyName      = Input::get('companyName');
            $job->jobDescription      = Input::get('jobDescription');
            $job->jobLocation = Input::get('jobLocation');
            $job->employmentType = Input::get('employmentType');
            $job->save();
            
            // redirect
            //Session::flash('message', 'Successfully updated shark!');
            return Redirect::to('jobs.index');
        //}
    }
    
    public function destroy($id)
    {
        // delete
        $job = job::find($id);
        $job->delete();
        
        // Redirect
        //Session::flash('message', 'Successfully deleted the job');
        return Redirect::to('jobs.index');
    }
    
    // Return a Search Page
    public function searchPage()
    {
        return view('jobs.searchJob');
    }
    
    // Search Method
    public function search(){
        if(request()->query('search')) {
            dd(request()->query('search'));
        }
        return view('jobs.searchJob');
    }
    
    // Details Method
    public function details($id)
    {
        $job = job::find($id);
        
        // validate
        $rules = array(
            'jobTitle'       => 'required',
            'companyName'      => 'required|companyName',
            'jobDescription'      => 'required|jobDescription',
            'jobLocation' => 'required|jobLocation',
            'employmentType' => 'required|employmentType',
            'applicants' => 'required|applicants'
        );

        return view('jobs.details')->with('job', $job);
    }
    
    // For Users/Admins to join an affinity group
    public function apply($id)
    {
        // store
        $job = job::find($id);
        $user = auth()->user();
        
        //$user = //user::find($name);
        //$group->members = Input::get('members', $user->name);
        $job->applicants = Input::get('applicants', $user->name);
        $job->save();
        // redirect
        //Session::flash('message', 'Successfully updated ');
        return redirect()->back();
    }
    
    // Search function
    public function searchPageHandler()
    {    // Connect to the database
       /*  $servername = "localhost";
        $username = "root";
        $password = "root";
        $database_name = "networkapp";
        
        $connection = mysqli_connect($servername, $username, $password, $database_name);
    
        $searchForTitle = $_GET['jobTitle'];
        // select jobs from the database
        $sql_statement = "SELECT * FROM jobs WHERE jobTitle LIKE '%$searchForTitle%'";
        // Show the jobs the user searched for

        if($connection)
        {
            $result = mysqli_query($connection, $sql_statement);
            if($result) {
                while($row = mysqli_fetch_assoc($result)) {                    
                    echo "==================";
                    echo "Job Title: " . $row['jobTitle'] . "<br>";
                    echo "==================";                    
                }
            } else {
                echo "Error with the SQL " . mysqli_error($connection);
            }
        } else {
            echo "Error Connecting " . mysqli_connect_error();
        } */
        return view('jobs.searchResults')->with('jobs', Job::all());
    }    
}
